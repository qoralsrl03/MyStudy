function fn_over(obj) {
    console.log('콘솔에 프린트됨')
    console.log(obj)
    obj.src='media/다운로드.jpeg';
   }
   function fn_out(obj) {
    obj.src='media/다운로드 (1).jpeg';
   }